public enum Acceptance {
    ACCEPTED,
    NOT_ACCEPTED
}
