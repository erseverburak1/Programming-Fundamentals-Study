public interface ICargo<T> {
     int getWeight();
     int getWidth();
     int getLength();
     int getHeight();
}