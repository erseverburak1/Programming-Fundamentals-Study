package Forecast;

/**   
 * Weather object class with all getter methods
* @author  Samet Umut Yiğitoğlu
* @author  Oğuzhan Karatepe
*/
public class Weather {
	private int wind;
	private int temperature;
	private int feelsTemperature;
	private int humidity;
	private int precipitation;
	private String visibility;
	
	public Weather(int wind, int temperature, int feelsTemperature, int humidity, int precipitation, String visibility) {
		this.wind=wind;
		this.temperature=temperature;
		this.feelsTemperature=feelsTemperature;
		this.humidity=humidity;
		this.precipitation=precipitation;
		this.visibility=visibility;
	}
	
	public int getFeelsTemperature() {
		return feelsTemperature;
	}

	public int getHumidity() {
		return humidity;
	}

	public int getPrecipitation() {
		return precipitation;
	}

	public String getVisibility() {
		return visibility;
	}

	public int getWind() {
		return wind;
	}
	
	public int getTemperature() {
		return temperature;
	}
}
