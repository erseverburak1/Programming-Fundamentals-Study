package Forecast;
import java.io.IOException;
/**   
 * We are using WeatherQuery class as an helper class for our 
 * WeatherForecastApp class. That class has the basic querying method to  
 * satisfy homework requirements 
* @author  Samet Umut Yiğitoğlu 260201056
* @author  Oğuzhan Karatepe 240201119 
*/
public class WeatherQuery{
	
	//CityWeather Object Array
	private CityWeather[][] weeklyForecast;
	//Our helper class WeeklyForecastInitialize;
	private WeeklyForecastInitialize forecastInitialize;
	
	//In our constructor we are initializing our forecastApp and 
	//then calling required object array data use in querying methods.
	public WeatherQuery() throws IOException { }
	{
		forecastInitialize=new WeeklyForecastInitialize();
		weeklyForecast=forecastInitialize.getWeeklyForecast();
	}
	
	/*
	 * method that returns lowest feels city names as a string value
	 */
	public String getLowestFeelsLikeTemperature() {
		String cityNames = "";
		int lowestTemp=100; //100 cannot be reached.
        
		// my first goal is to find lowest feel temperature first 
		for(int i=1; i<weeklyForecast.length; i++) {
			for(int j=0; j<7; j++) {
				if(weeklyForecast[i][j].getWeather().getFeelsTemperature()<=lowestTemp) {
					lowestTemp=weeklyForecast[i][j].getWeather().getFeelsTemperature();
				}
			}
		}
		
		// then I am looking for cities that have feels temperature equals to lowest one
		for(int i=1; i<weeklyForecast.length; i++) {
			for(int j=0; j<7; j++) {
				if(weeklyForecast[i][j].getWeather().getFeelsTemperature()<=lowestTemp) {
					cityNames+=weeklyForecast[i][j].getCity().getName()+", ";
				}
			}
			
		}
		
		return cityNames.substring(0, cityNames.length() - 2);//I am using substring method delete last comma
	}
	
	/*
	 * In this method we are calculating our top 3 variations
	 * to be able to do this first we are finding standard deviation for each city temperature
	 * then storing the top 3 value in the variations array;
	 */

	public String getHighestTemperatureVariation() {
		double[] variations={0,0,0}; //variations[0] for highest, variations[1] for second highest, variations[2] for third highest.
		String[] variationsName=new String[3]; //variationsName[0] for highest, variationsName[1] for second highest, variationsName[2] for third highest. To store city objects.
		double varAverage;
		double standartDev;

		for(int i=1; i<weeklyForecast.length; i++) {
			int totalTempValue=0;
			standartDev=0;
			
			for(int j=0; j<7; j++) {
				totalTempValue+=weeklyForecast[i][j].getWeather().getTemperature();
			}
			varAverage=totalTempValue/7;
			
			for(int j=0; j<7; j++) {
				standartDev+=Math.pow((weeklyForecast[i][j].getWeather().getTemperature()-varAverage), 2);
			}
			standartDev=Math.pow(standartDev/6, 0.5); //devide by n-1
			
			for(int j=0; j<3; j++) {
				if(variations[j]<standartDev) {
					variations[j]=standartDev;
					variationsName[j]=weeklyForecast[i][0].getCity().getName();
					break;
				}
				else if(variations[j]==standartDev) {
					variationsName[j]=variationsName[j]+", "+weeklyForecast[i][0].getCity().getName();
					break;
				}
			}
		}
		return variationsName[0]+", "+variationsName[1]+", "+variationsName[2];
	}
	
	/*
	 * In this method we are calculation the average humidity for each region 
	 * for the next week and finding the biggest region average region humidity value; 
	 */
	public String getHighestAverageHumidity() {
		Region[] regions=forecastInitialize.getRegionsWithCities();
		String maxHumidityRegionName="There is no region to calculate Humidity";
		double maxHumidityAverage=0;
		
		for(int i=1; i<regions.length; i++) {
			Region region=regions[i];
			double totalHumidity = 0;
			for(City city:region.getCities()) {
				for(int j=0; j<7; j++) {
					totalHumidity +=weeklyForecast[city.getPlate()][j].getWeather().getHumidity();
				}
			}
			totalHumidity=totalHumidity/(region.getCities().length*7);
			
			
			if(totalHumidity>maxHumidityAverage) {
				maxHumidityAverage=totalHumidity;
				maxHumidityRegionName=region.getName();
			}
		}
		return maxHumidityRegionName;
	}
	
	/*
	 * The method first finds which cities has the highest and lowest altitudes
	 * then it calculates and returns average temperatures of that cities
	 */
	public String getMeanTemperatures() { 
		
		int[] altitudes= {-1,-1}; //altitudes[0] for lowest altitudes[1] for highest
		int[] plateNumbers=new int[2];
		double highestAltitudeTotalTemperature=0;
		double lowestAltitudeTotalTemperature=0;
		
		for(int i=1; i<weeklyForecast.length; i++) {
			if(altitudes[0]==-1 || weeklyForecast[i][0].getCity().getAltitude()<altitudes[0]) {
				altitudes[0]=weeklyForecast[i][0].getCity().getAltitude();
				plateNumbers[0]=weeklyForecast[i][0].getCity().getPlate();
			}
			if(altitudes[1]==-1 || weeklyForecast[i][0].getCity().getAltitude()>altitudes[1]) {
				altitudes[1]=weeklyForecast[i][0].getCity().getAltitude();
				plateNumbers[1]=weeklyForecast[i][0].getCity().getPlate();
			}
		}
		for(int i=0; i<7; i++) {
			lowestAltitudeTotalTemperature+=weeklyForecast[plateNumbers[0]][i].getWeather().getTemperature();
			highestAltitudeTotalTemperature+=weeklyForecast[plateNumbers[1]][i].getWeather().getTemperature();
		}
		//I am using math.round method to match output length with example Expected Output Format defined in homework
		return Math.round(highestAltitudeTotalTemperature/7 * 1000.0)/1000.0+", "+Math.round(lowestAltitudeTotalTemperature/7*1000.0)/1000.0; 
	}
	
	/*
	 * getRainyCities just checks 2. and 3. days rain precipitation if they bigger or equal to 80%
	 * if they are then returns that city names
	 */
	public String getRainyCities() {
		String rainyCities="";

		for(int i=1; i<weeklyForecast.length; i++) {
			if(weeklyForecast[i][1].getWeather().getPrecipitation()>=80 && weeklyForecast[i][2].getWeather().getPrecipitation()>=80) {
					rainyCities+=weeklyForecast[i][0].getCity().getName()+", ";
				}
			}
		return rainyCities.substring(0,rainyCities.length()-2); //I am using substring method delete last comma
	}
	
	/*
	 *Method that returns suitable days for drone fly
	 */
	public String getDatesForDrone(String cityName) {
		String allowedDates="";
		boolean validCity=false;
		for(int i=1; i<weeklyForecast.length; i++) {
			
			if(weeklyForecast[i][0].getCity().getName().equalsIgnoreCase(cityName)) {
				validCity=true;
				for(int j=0; j<7; j++) {
					if(weeklyForecast[i][j].getWeather().getWind()<40 && !(weeklyForecast[i][j].getWeather().getVisibility().equals("low"))) {
							allowedDates+=weeklyForecast[i][j].getDate()+", ";
						
					}
				}
			}
		}
		if(!validCity) {
			return "Your input is not matching with any city name please run program again and be sure your input is a city name!!";
		}
		else if(allowedDates=="") {
			return "No suitable day in "+cityName +" for drone fly";
		}
		else {
			return allowedDates.substring(0,allowedDates.length()-2); //I am using substring method delete last comma
		}
		
	}
}
