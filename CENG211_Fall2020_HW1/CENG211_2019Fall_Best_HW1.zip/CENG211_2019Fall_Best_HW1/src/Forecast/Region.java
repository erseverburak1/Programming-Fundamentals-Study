package Forecast;

/**   
 *Region object class with its getters and setCities method
* @author  Samet Umut Yiğitoğlu
* @author  Oğuzhan Karatepe
*/
public class Region {
	private int id;
	private String name;
	private City[] cities;
	
	public Region(int id, String name) {
		this.id=id;
		this.name=name;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public City[] getCities() {
		return cities;
	}
	
	public void setCities(City[] cities) {
		this.cities=cities;
	}
}
