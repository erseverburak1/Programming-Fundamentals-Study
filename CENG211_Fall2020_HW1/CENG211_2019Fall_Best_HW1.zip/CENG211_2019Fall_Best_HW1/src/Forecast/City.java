package Forecast;
/**   
 * City object class with its getters
* @author  Samet Umut Yiğitoğlu
* @author  Oğuzhan Karatepe
*/
public class City {
	private int plate;
	private String name;
	private Region region;
	private int altitude;
	
	public City(int plate, String name, Region region, int altitude) {
		this.plate=plate;
		this.name=name;
		this.region=region;
		this.altitude=altitude;
	}

	public int getPlate() {
		return plate;
	}

	public String getName() {
		return name;
	}

	public Region getRegion() {
		return region;
	}

	public int getAltitude() {
		return altitude;
	}
}
