package Forecast;
import java.io.IOException;
import java.util.StringTokenizer;

import FileAccess.FileIO;
/**   
 * We are using WeeklyForecastInitialize class as an helper class for our 
 * WeatherQuery class. Basic responsibility of that class is to convert string arrays 
 * to object array. 
* @author  Samet Umut Yiğitoğlu
* @author  Oğuzhan Karatepe
*/
public class WeeklyForecastInitialize {
	private FileIO file;
	private City[] cities;
	private Region[] regions;
	
	//constructor of class
	public WeeklyForecastInitialize() throws IOException { 
		file=new FileIO();
		// we call that void method in constructor to fill city and region arrays 
		//by the creation of WeeklyForecastInitialize class 
		initializeStringDataToObjectArrays();
	}
	
	/*
	 * method where we convert cities string data arrays to 
	 * city and region object arrays.
	 */
	public void initializeStringDataToObjectArrays() throws IOException {
		 String[][] fCities=file.getCities(); 
		 
 		cities=new City[fCities.length];
		regions=new Region[8];// There is no 0 id.
		
 		for(int i=1; i<fCities.length; i++) {
			int plate=Integer.parseInt(fCities[i][0]);
			String name=fCities[i][1];
			int regionId=Integer.parseInt(fCities[i][2]);
			String regionName=fCities[i][3]; 
			int altitude=Integer.parseInt(fCities[i][4]);
			if(regions[regionId]==null) {
				regions[regionId]=new Region(regionId, regionName);
			}
			
			cities[i]=new City(plate, name, regions[regionId], altitude);
		}
	}
	
	/*
	 * This the method that converts weather string data to cityWeather objects array
	 */
	public CityWeather[][] getWeeklyForecast() throws IOException {
		String[][] fWeathers=file.getWeather();
		CityWeather[] tWeathers=new CityWeather[fWeathers.length];
		
		
		CityWeather[][] weeklyForecast=new CityWeather[82][7];
 		for(int i=0; i<fWeathers.length; i++) {
 			City city=cities[Integer.parseInt(fWeathers[i][0])];
 			String date=fWeathers[i][1];
 			int wind=Integer.parseInt(fWeathers[i][2]);
 			int temperature=Integer.parseInt(fWeathers[i][3]);
 			int feelsTemperature=Integer.parseInt(fWeathers[i][4]);
 			int humidity=Integer.parseInt(fWeathers[i][5]);
 			int precipitation=Integer.parseInt(fWeathers[i][6]);
 			String visibility=fWeathers[i][7];
 			tWeathers[i]=new CityWeather(city, new Weather(wind, temperature, feelsTemperature, humidity, precipitation, visibility), date);
 		}
 		
 		for(int i=0; i<tWeathers.length; i++) {
 			String date=tWeathers[i].getDate();
 			StringTokenizer st=new StringTokenizer(date,".");
 			int iDate=Integer.parseInt(st.nextToken())-14;
 			weeklyForecast[tWeathers[i].getCity().getPlate()][iDate]=tWeathers[i];
 		}
		 return weeklyForecast;
	}
	
	/*
	 *getRegionsWithCities method returns regions with cities if needed
	 */
	public Region[] getRegionsWithCities() {
		for(int i=1; i<8; i++) {
 			int count=0;
 			int itemCount=0;
 			for(int j=1; j<cities.length; j++) {
 				if(cities[j].getRegion().getId()==i) count++;
 			}
 			City[] rCities=new City[count];
 			for(int j=1; j<cities.length; j++) {
 				if(cities[j].getRegion().getId()==i) {
 					rCities[itemCount++]=cities[j];
 				}
 			}
 			regions[i].setCities(rCities);
 		}
		return regions;
	}
}
