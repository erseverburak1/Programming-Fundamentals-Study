package Forecast;
/**   
 *  CityWeather object class with its getters
* @author  Samet Umut Yiğitoğlu
* @author  Oğuzhan Karatepe
*/
public class CityWeather {
	private City city;
	private Weather weather; 
	private String date;
	
	public CityWeather(City city, Weather weather, String date) {
		this.city=city;
		this.weather=weather;
		this.date=date;
	}

	public City getCity() {
		return city;
	}

	public Weather getWeather() {
		return weather;
	}

	public String getDate() {
		return date;
	}
}
