package ForecastApp;
import java.io.IOException;
import java.util.Scanner;
import Forecast.WeatherQuery;
/**   
 * This is our WeatherForecastApp where has the main method.
 * So program starts from here and creates an WeatherQuery class 
 * then calls our homework questions one by one
 * 
 * @author  Samet Umut Yiğitoğlu 260201056
 * @author  Oğuzhan Karatepe 240201119 
 */
public class WeatherForecastApp {
	public static void main(String args[]) throws IOException {

		WeatherQuery query=new WeatherQuery();
		System.out.println("1) "+query.getLowestFeelsLikeTemperature());
		System.out.println("2) "+query.getHighestTemperatureVariation());
		System.out.println("3) "+query.getHighestAverageHumidity());
		System.out.println("4) "+query.getMeanTemperatures());
		System.out.println("5) "+query.getRainyCities());
		System.out.println("6) Enter a city name to view flightworthy days:");

		Scanner scanner=new Scanner(System.in);
		String answer=scanner.nextLine();

		//user must enter a valid input to get correct answer
		if(answer.length()>=1) {
			String dates=query.getDatesForDrone(answer);
			System.out.println(dates);
		} else {
			System.out.println("You must type a city name to get answer!!");
		}

		scanner.close();
	}
} 