package FileAccess;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/** 
 This is our fileIO class. We read cities.csv and WeeklyForecast.csv data source files 
 by using two related methods in this class.   
* @author  Samet Umut Yiğitoğlu 260201056
* @author  Oğuzhan Karatepe 240201119 
*/
public class FileIO {
	
	//Our global field to read each line of files;
	 private String line;
	//Our global field to decide array size;
	 private int count;
	 
	 
	 /*
	  * In this getCities method we are trying to read Cities.csv file
	  * To be able to do this, we are using two general while loop
	  * first one is for to determine the size of cities array
	  * the second while loop that we read each line of file one by one 
	  * then we are assigning each cities fields to our 2 dimensional cities array
	  * by using internal while loop. 
	  */
	public String[][] getCities() throws IOException{
		count=0;
		int countRow=1;
		int countColumn=0;
	  
		//two dimensional cities array
		String cities[][] = null;
		
		try {
			FileReader fr = new FileReader("CENG211_HW1_Cities.csv");
			@SuppressWarnings("resource")
			BufferedReader br = new BufferedReader(fr);
			
			//loop to reach total city count
			while ((line=br.readLine()) !=null) {
				count++;
			}
			// need to close FileReader and BufferReader
	        fr.close();
	        br.close();
	       
	        //if there is any city data in that file
	        if(count>0) {
	        	cities = new String[count+1][5];
	        	
	        	FileReader fr2 = new FileReader("CENG211_HW1_Cities.csv");
		        BufferedReader secondBr = new BufferedReader(fr2);
		        
               //we are reading that cities data one by one
				while ((line=secondBr.readLine()) != null) {
				    countColumn=0;
					StringTokenizer st=new StringTokenizer(line,",");
					while(st.hasMoreElements()) {
						cities[countRow][countColumn++]=st.nextElement().toString();
					}
					
					countRow++;
				} 
				//need to close fileReader and buffer reader 
				secondBr.close();
				fr2.close();
	        }
			
		} catch(FileNotFoundException exception) {
			System.out.println("Cities file not found"); 
		} catch(IOException exception) {
			System.out.println(exception);
		}
		
		return cities;
	}
	
	
	
	
	 /*
	  * In this getWeather method we are trying to read WeeklyForecast.csv file
	  * To be able to do this, we are using two general while loop
	  * first one is for to determine the size of weathers array
	  * the second while loop that we read each line of file one by one 
	  * then we are assigning each weather information to our 2 dimensional weathers array
	  * by using internal while loop. 
	  */
	@SuppressWarnings("resource")
	public String[][] getWeather() throws IOException{
		count=0;
		int countColumn=0;
		int countRow=0;
		
		//two dimensional weathers array
		String weathers[][] = null;
		
		try {
			FileReader fr = new FileReader("CENG211_HW1_WeeklyForecast.csv");
			BufferedReader br = new BufferedReader(fr);
			//loop to reach total weather data count
			while ((line=br.readLine()) !=null) {
				count++;
			}
			// need to close FileReader and BufferReader
			  fr.close();
		      br.close(); 
		      
			//if there is any weather data in that file
			if(count>0) {
				weathers = new String[count][8];
				FileReader fr2 = new FileReader("CENG211_HW1_WeeklyForecast.csv");
				BufferedReader secondBr = new BufferedReader(fr2);
				
				 //we are reading that weathers data one by one
				while ((line=secondBr.readLine()) != null) {
					countColumn=0;
					StringTokenizer st=new StringTokenizer(line,",");
					while(st.hasMoreElements()) {
						weathers[countRow][countColumn++]=st.nextElement().toString();
					}
					countRow++;
				}
				
				// need to close FileReader and BufferReader
				fr2.close();
				secondBr.close();
			}
			
			
		} catch(FileNotFoundException exception) {
			System.out.println("Weathers file not found"); 
		} catch(IOException exception) {
			System.out.println(exception);
		}
		
		return weathers; 
	}
}
